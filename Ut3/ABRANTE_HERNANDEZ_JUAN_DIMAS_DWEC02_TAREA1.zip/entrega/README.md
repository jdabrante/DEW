## Práctica 1

<div align = "justify">

La siguiente práctica tiene como objetivo aprender a utilizar los bucles, condicionales y desplazamiento de bits.

Ademas se han intentado usar algunos recursos adicionales como puede ser bootstrap simplemente para practicar el manejo de este framework.

Por otro lado, en el caso de la actividad 1 de esta práctica, se ha modificado en cierta medida lo que pedia la misma para poder hacer uso y explorar otras funcionalidades que ofrece JavaScript.
</div>